package com.cg.product.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.product.beans.Products;
import com.cg.product.daoservices.IProductDAO;
import com.cg.product.exceptions.ProductDetailsNotFound;
@Component("iproduct")
public class IProductServiceImpl implements IProductService{
	@Autowired
	IProductDAO iproductDao;

	@Override
	public Products acceptProductDetails(Products products) {
		products = iproductDao.save(products);
		return products;
	}

	@Override
	public Products getProductsDetails(String prodId) throws ProductDetailsNotFound {
		Products products = iproductDao.findById(prodId).orElseThrow
				(()->new ProductDetailsNotFound("Products details not found product Id"+prodId));
		if(products == null)
			throw new ProductDetailsNotFound("Products Details not found for Id:" +prodId);
		return products;
	}
	

	@Override
	public List<Products> getAllProductsDetails() {
		return iproductDao.findAll();
	}

	@Override
	public Products updateProductsDetails(String prodId, Products newProducts) throws ProductDetailsNotFound {
		Products products = iproductDao.findById(prodId).orElseThrow
				(()->new ProductDetailsNotFound("Products details not found movie Id"+prodId));
		if(products == null)
			throw new ProductDetailsNotFound("Products Details not found for Id:" +prodId);
		products.setProdId(newProducts.getProdId());
		products.setProdName(newProducts.getProdName());
		products.setProdModel(newProducts.getProdModel());
		products.setProdPrice(newProducts.getProdPrice());
		return products;
	}
	

	@Override
	public boolean removeProductsDetails(String prodId) throws ProductDetailsNotFound {
		iproductDao.delete(getProductsDetails(prodId));
		return true;
	}

	@Override
	public Products findProduct(String prodId) throws ProductDetailsNotFound {
		Products products = iproductDao.findById(prodId).orElseThrow(()->new ProductDetailsNotFound("Sorry Product Not Found!!!"));
		return products;
	}

}
