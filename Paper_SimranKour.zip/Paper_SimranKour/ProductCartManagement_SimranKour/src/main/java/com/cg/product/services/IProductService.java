package com.cg.product.services;
import java.util.List;
import com.cg.product.beans.Products;
import com.cg.product.exceptions.ProductDetailsNotFound;

public interface IProductService {
	Products acceptProductDetails(Products products);
	//creating Products
	Products getProductsDetails(String prodId) throws ProductDetailsNotFound;
	//viewing Products
	List<Products> getAllProductsDetails();
	//viewing all products
	public Products findProduct(String prodId) throws ProductDetailsNotFound;
	//finding Product details
	Products updateProductsDetails(String prodId,Products newProducts)throws ProductDetailsNotFound;
	//updating Products
	boolean removeProductsDetails(String prodId) throws ProductDetailsNotFound;
	//deleting Products
}
