package com.cg.product.daoservices;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.cg.product.beans.Products;

public interface IProductDAO extends JpaRepository<Products, String>{
	
	//@Query(value="from Product p where p.prodId = :prodId")
	//Products findOne(String prodId);
	

}
