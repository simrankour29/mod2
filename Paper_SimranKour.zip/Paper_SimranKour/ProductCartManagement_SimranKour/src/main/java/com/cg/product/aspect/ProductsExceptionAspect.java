package com.cg.product.aspect;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.product.exceptions.ProductDetailsNotFound;
import com.cg.product.responses.CustomResponse;


@Controller
@ControllerAdvice
public class ProductsExceptionAspect {
	@ExceptionHandler(ProductDetailsNotFound.class)
	public ResponseEntity<CustomResponse> handleProductDetailsNotFound(Exception e) {
		CustomResponse response	=new CustomResponse(e.getMessage(),HttpStatus.EXPECTATION_FAILED.value());
			 return new ResponseEntity<>(response , HttpStatus.EXPECTATION_FAILED );
	}
}
