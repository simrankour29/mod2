package com.cg.product.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import com.cg.product.beans.Products;
import com.cg.product.exceptions.ProductDetailsNotFound;
import com.cg.product.services.IProductService;

	@Controller
		public class ProductsController {
	@Autowired
		IProductService iproduct;
	
	@RequestMapping(value= {"/sayHello"},method=RequestMethod.GET)
	public ResponseEntity<String> sayHello(){
		return new ResponseEntity<String>("Hello Hello",HttpStatus.OK);
		
	}
	
	@RequestMapping(value="/acceptProductDetails", method=RequestMethod.POST)
	   public ResponseEntity<String> acceptProductDetails(@ModelAttribute Products products)
	   {
		   products = iproduct.acceptProductDetails(products);
	   	   return new ResponseEntity<String>("Product Details Accepted Successfully!\n" + products,HttpStatus.OK);
	   }
	   
	   
	@RequestMapping(value= {"/findProduct"},method=RequestMethod.GET,
			produces= MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<Products> getProductDetailsRequestParam(@RequestParam String id )throws ProductDetailsNotFound{
		Products products =iproduct.findProduct(id);
		return new ResponseEntity<Products>(products,HttpStatus.OK);
	}
	
	@RequestMapping(value= {"/getAllProductsDetails"},method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<List<Products>> getAllProduuctsDetailsPathParam(){
		return new ResponseEntity<List<Products>>(iproduct.getAllProductsDetails(),HttpStatus.OK);
	}
	
	@RequestMapping(value= {"/updateProductsDetails"},method=RequestMethod.PUT)
	public ResponseEntity<String>updateProductDetails(@RequestParam String prodId,@ModelAttribute Products newProducts) throws ProductDetailsNotFound{
		Products products=iproduct.updateProductsDetails(prodId,newProducts);
		return new ResponseEntity<>("Movie details updated added movie Id:-"+prodId,HttpStatus.OK);
	}
	
	@RequestMapping(value="/removeProductsDetails",method=RequestMethod.DELETE)
	public ResponseEntity<String> removeProductsDetails(@RequestParam String prodId) throws ProductDetailsNotFound{
		iproduct.removeProductsDetails(prodId);
		return new ResponseEntity<>("Product Details successfully Removed",HttpStatus.OK);
	}

	  
}
